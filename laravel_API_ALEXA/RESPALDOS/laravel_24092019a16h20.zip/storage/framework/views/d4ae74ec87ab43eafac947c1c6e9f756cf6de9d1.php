<!DOCTYPE html>
<html lang="en">

<head>
 
</head>

<body class="hold-transition skin-blue sidebar-mini">
   <?php echo $__env->yieldContent('row'); ?>
    <section class="content-header" style="background-color:white">

      <h1 style="text-transform: uppercase;">
        <?php echo e($factor); ?>

      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-area-chart"></i> Alexa</a></li>
        <li class="active">Indicadores</li>
        <li class="active"><?php echo e($indicator); ?></li>
        <li class="active"><?php echo e($mes); ?></li>
      </ol>
    </section>

    
    
<?php $__env->startSection('contenido'); ?>
  <!-- GRAFICO , PORCENTUALES , ACTIVITY -->
<?php $__env->stopSection(); ?>
</div>

  <!-- ACTIVITY AQUI.. -->

  <!--INTERPRETACION HERE -->


</body>

</html>
<?php echo $__env->make('layouts.content', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>