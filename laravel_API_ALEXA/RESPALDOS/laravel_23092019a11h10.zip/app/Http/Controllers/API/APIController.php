<?php

namespace App\Http\Controllers\API;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Repositories\APIServiceRepository;

class APIController extends Controller
{

    public function prueba_api()
    {
      echo "Prueba api";

    }

// login
     public function getUser($nombre, $contrasena)
  {
    $api = new  APIServiceRepository();
    $usuario = $api->getUser($nombre, $contrasena);
    if (empty($usuario)) {
      return response()->json([
        'data' => [
          'mensaje' => "Usuario no encontrado",
          'status' => 0 
        ]
      ]);
    }else{
      return response()->json([
        'data'=> [
        'email' => $usuario[0]->email,
        'name' => $usuario[0]->name,
        'status' => 1 
        ]
    ]);
    }
    
  }
//usuario -- valdiacion
 public function getUser_validate($nombre)
  {
    $api = new  APIServiceRepository();
    $usuario = $api->getUser_validate($nombre);
    if (empty($usuario)) {
      return response()->json([
        'data' => [
          'mensaje' => "Usuario no encontrado",
          'status' => 0 
        ]
      ]);
    }else{
      return response()->json([
        'data'=> [
        'mensaje' => "Usuario encontrado",
        'status' => 1 
        ]
    ]);
    }
    
  }
  
  
  // Area
  public function getArea(){
      
      $api = new APIServiceRepository();
      $areas_name = $api->getArea();
      //validacion
      if(empty($areas_name)){
          return response()->json([
              'data'=>[
                  'mensaje'=> "No se encuentran areas registradas",
                  'status' => 0
                  ]
              ]);
      }else{
          $nombres_areas= array();
          for( $i= 0 ; $i < count($areas_name) ; $i++){
             // echo $areas_name[$i]->name;
              array_push($nombres_areas,$areas_name[$i]->name);
              //Financiera , comercial, contable
              
          }
          return response()->json([
              'data'=>[
                  'areas' => $nombres_areas,
                  'status' => 1
                  ]
              ]); 
          
      }
  }
  
  // GET FACTORES MEDIANTE AREAS DESCRIPTION
     public function getAreaDescription($description)
  {
    $api = new  APIServiceRepository();
    $factores = $api->getAreaDescription($description);
    if (empty($factores)) {
      return response()->json([
        'data' => [
          'mensaje' => "area no encontrada segun el factor asignado",
          'status' => 0 
        ]
      ]);
    }else{
          $factoresPorArea= array();
          for( $i= 0 ; $i < count($factores) ; $i++){
             // echo $areas_name[$i]->name;
              array_push($factoresPorArea,$factores[$i]->name);
              //Financiera , comercial, contable
              
          }
      return response()->json([
        'data'=> [
        'factoresPorArea' => $factoresPorArea,
        'status' => 1 
        ]
    ]);
    }
    
  }
  // indicadores mediante factor nombre
  public function getIndicatorByFactor($factor){
     
      $api = new  APIServiceRepository();
    $indicadores = $api->getIndicatorByFactor($factor);
    if (empty($indicadores)) {
      return response()->json([
        'data' => [
          'mensaje' => "Indicador no encontrado",
          'status' => 0 
        ]
      ]);
    }else{
         $indicadorPorFactor= array();
          for( $i= 0 ; $i < count($indicadores) ; $i++){
              array_push($indicadorPorFactor,$indicadores[$i]->name);
              }
      return response()->json([
        'data'=> [
        'factor' => $factor,
        'indicadores' => $indicadorPorFactor,
        'status' => 1 
        ]
    ]);
    } 
  } 

  // *****  MONTHLY ****
  // YEAR
   public function getMonthly($anio, $nombre)
  {
    $api = new  APIServiceRepository();
    $monthly = $api->getMonthly($anio, $nombre);
    if ($monthly[0]->sumaActual === null) {
      return response()->json([
        'data' => [
          'mensaje' => "No monthly",
          'status' => 0 
        ]
      ]);
    }else{
         $anio = "año";
       return response()->json([
        'data'=> [
        'indicator' => $nombre,
        'monthly' => $monthly,
        'resta'=> round($monthly[0]->sumaActual - $monthly[0]->sumaAnterior, 2),
        'variacion' => round((($monthly[0]->sumaActual-$monthly[0]->sumaAnterior)/$monthly[0]->sumaAnterior)*100,2),
        'definicion' =>'es de ' .$monthly[0]->sumaActual. ' versus el '.$anio.'  anterior, que fue de ' .$monthly[0]->sumaAnterior. ' . La variacion es de ' .round($monthly[0]->sumaActual - $monthly[0]->sumaAnterior, 2). ' correspondiente al ' .round((($monthly[0]->sumaActual-$monthly[0]->sumaAnterior)/$monthly[0]->sumaAnterior)*100,2). ' %',
        'status' => 1  
        ]
    ]);
    }
    
  }

    //MONTH
      public function getMonthlyMonth($mes,$anio, $nombre)
    {
    $api = new  APIServiceRepository();
    $monthlyMonth = $api->getMonthlyMonth($mes,$anio, $nombre);
    
    
    if (empty($monthlyMonth)) {
      return response()->json([
        'data' => [
          'mensaje' => "No monthly",
          'status' => 0 
        ]
      ]);
    }else{
      return response()->json([
        'data'=> [
        'indicator' => $nombre,
        'monthly' => $monthlyMonth,
        'resta'=> round($monthlyMonth[0]->current_month -$monthlyMonth[0]->last_month, 2),
        'variacion' => $monthlyMonth[0]->variation_between_months,
        'definicion' =>'es de ' .$monthlyMonth[0]->current_month. ' versus el mes anterior, que fue de ' .$monthlyMonth[0]->last_month. ' . La variacion es de ' .round($monthlyMonth[0]->current_month - $monthlyMonth[0]->last_month, 2). ' correspondiente al ' .$monthlyMonth[0]->variation_between_months. ' %',
        'status' => 1  
        ]
    ]);
    }
    
  }
    public function comparation($indicador){
    $api = new  APIServiceRepository();
    $comparation = $api->comparation($indicador);
    
    
    if (empty($comparation)) {
      return response()->json([
        'data' => [
          'mensaje' => "No comparation",
          'status' => 0 
        ]
      ]);
    }else{
      return response()->json([
        'data'=> [
        'indicator' => $indicador,
        'txt_affirmative'=> $comparation[0]->txt_affirmative,
        'status' => 1  
        ]
    ]);
    }
    }
}
