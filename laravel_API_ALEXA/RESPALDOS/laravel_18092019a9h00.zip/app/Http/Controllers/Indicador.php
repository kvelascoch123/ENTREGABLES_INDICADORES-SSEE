<?php

namespace App\Http\Controllers;

use App\Repositories\DataServiceRepository;
use App\Clases\Test;
use Illuminate\Support\Facades\DB;

class Indicador extends Controller
{

    // ****************SEGUNDA ETAPA***************************************** //

    // Indicador por mes    //3 parametros  $indicator, $mes, $a���o

    // IndicadorMesAño 
    public function indicatorMonthYear($indicador, $mes, $anio)
    {

        $gestion =  new DataServiceRepository();
        
        //DATA
        $indicadores = $gestion->indicatorMonthYear($indicador, $mes, $anio);
        $factor = $indicadores[0]->description;
        $indicator = $indicadores[0]->name;
        $mes = $indicadores[0]->month; // actual    
        $mes_anterior_name = $gestion->mes_anterior_name($mes);
       
        // DATA VALORES
        $mes_actual = $indicadores[0]->current_month;
        $mes_anterior = $indicadores[0]->last_month; // funcion determina el mes
        $variacion = $indicadores[0]->current_month - $indicadores[0]->last_month;

        // CALCULO 
        $valor = $indicadores[0]->current_month;
      
        return view('index', compact('factor', 'indicator', 'mes','mes_anterior_name', 'mes_actual', 'mes_anterior', 'variacion', 'valor'));
        /*
        http://www.sidesoft.com.ec/app_indicadores/indicadorMY/liquidez%20corriente/enero/2019
        */
        // Funcionalidad => F1.

    }

    // Todos los indicadores en el año
    public function indicatorYear($indicator, $anio)
    {

        $gestion =  new DataServiceRepository();
        //DATA
        $indicadores = $gestion->indicatorYear($indicator,  $anio);
        $factor = $indicadores[0]->description;
        $indicator = 'Indicador '. $indicadores[0]->name. ' respecto al año ' . $indicadores[0]->year;     //$indicadores[0]->name;
        $mes = '';
        $año = $indicadores[0]->year; //2019
        $año_anterior = $indicadores[0]->year-1; // 2018
    

        //DATA VALORES
        $valoresCurrent = $gestion->indicatorYearValuesCurrent($indicadores[0]->name, $indicadores[0]->year);
        $anio_actual_value = $valoresCurrent[0]->current_year;  // Sumatoria del valor del año actual
     
        $valoresLast = $gestion->indicatorYearValuesLast($indicadores[0]->name, $indicadores[0]->year);
        $anio_anterior_value = $valoresLast[0]->last_year;  // Sumatoria del valor del año actual

        $variacion = $anio_actual_value - $anio_anterior_value;
        $valor = $indicadores[0]->current_month;
       // return $valores;
        return view('index', compact('factor', 'indicator', 'mes','anio','año_anterior', 'anio_actual_value', 'anio_anterior_value', 'variacion', 'valor'));
        /*
        http://www.sidesoft.com.ec/app_indicadores/indicadorT/endeudamiento%20del%20activo/septiembre/2018
     
        // Funcionalidad => F2.
*/
    }

    public function proporsionales(){
        $gestion =  new DataServiceRepository();

        $total_proporcional = $gestion->calcularProporcional('rotacion de cartera', 2019);
        $valor_proporcional_mes = $gestion->proporcionalTotalYear('rotacion de cartera', 2019);
     
       // return $valor_proporcional_mes[0]->total_months;
        return compact('total_proporcional','valor_proporcional_mes');
    }

    // *** Funcionalidades ***

    // F1. ) Cuando en la url se ingresa tres parametros indicador/mes/año => valor del CHART = VALOR DEL MES

    // F2. ) Cuando en la url se ingresa dos parametros indicadir/año => valor del CHART = SUMATORIA DE TODOS LOS MESES / # 


}

