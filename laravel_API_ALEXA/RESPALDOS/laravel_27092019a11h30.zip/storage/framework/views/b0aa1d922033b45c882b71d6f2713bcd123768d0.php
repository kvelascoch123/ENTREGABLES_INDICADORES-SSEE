
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>

  <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
   <script type="text/javascript">
      google.charts.load('current', {'packages':['gauge']});
      google.charts.setOnLoadCallback(drawChart);

      function drawChart() {

        var data = google.visualization.arrayToDataTable([
          ['Label', 'Value'],

            <?php $__currentLoopData = $indicadores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $indicadores): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                ['<?php echo e($indicadores->name); ?>', <?php echo e($indicadores->current_year); ?>],
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        ]);

        var options = {
       
          width: 400, height: 400,
          redFrom: 90, redTo: 100,
          yellowFrom:75, yellowTo: 90,
          minorTicks: 5
        };

        var chart = new google.visualization.Gauge(document.getElementById('chart_div'));

        chart.draw(data, options);

        
      }
    </script>
</head>
<style>
.jumbotron {
     
     background-color: gray;
     background-image: url("https://www.heflo.com/es/wp-content/uploads/sites/6/2018/04/indicadores-de-performance-para-os-processos-empresariais-1280x720.jpg");
}
</style>
<body>
<nav class="navbar navbar-expand-sm bg-dark navbar-dark">
   <a class="navbar-brand" href="#">
    <img src="http://www.sidesoft.com.ec/wp-content/uploads/2015/10/Logo2014v1.png" alt="Logo" style="width:50%;">
  </a>
</nav>

<div class="jumbotron text-center">
<br><br><br><br><br><br>
</div>
<div class="container">
   <div class="row">
    <div class="col-sm-3">
     
    </div>
    <div class="col-sm-6">
    <h3  class="text-primary"> <b> Bienvenido al indicador de <?php echo e($indicadores->description); ?> </b> </h3> 
    </div>
    <div class="col-sm-3">
      
    </div>
  </div>
</div>
  


<div class="container">
  <div class="row">
    <div class="col-sm-3">

      <h5>Detalles del indicador</h5>
      <div class="card">
      
    <div class="card-body">
    <h5 class="text-uppercase" ><?php echo e($indicadores->name); ?></h5>
    <p class="card-text">Año pasado: <?php echo e($indicadores->last_year); ?> </p>
    <p class="card-text">Año presente: <?php echo e($indicadores->current_year); ?> </p>
    <p class="card-text">Variacion año: <?php echo e($indicadores->variation_between_years); ?> </p>
    <p class="card-text">Mes anterior: <?php echo e($indicadores->last_month); ?> </p>
    <p class="card-text">Mes presente: <?php echo e($indicadores->current_month); ?> </p>
    <p class="card-text">Variacion mes: <?php echo e($indicadores->variation_between_months); ?> </p>

  </div>
</div>
       </div>
    <div class="col-sm-6">
    <div id="chart_div" ></div>
 
     </div>
    <div class="col-sm-3">
     <!-- Button trigger modal -->
     <h5>Deseas interpretar los datos del indicador ? </h6>
      <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal">
        Interpretar
      </button>

<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <p></p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary">Save changes</button>
      </div>
    </div>
  </div>
</div>
       </div>
  </div>
</div>

</body>
</html>







