<!DOCTYPE html>
<html lang="en">
<head>


</head>
<body>


<?php $__env->startSection('row'); ?>

<?php $__env->stopSection(); ?>



<?php $__env->startSection('header'); ?>
<header class="main-header">

</header>
<?php $__env->stopSection(); ?>


</body>

<!-- jQuery 2.2.0 -->

<script type="text/javascript" src="<?php echo e(asset('plugins/jQuery/jQuery-2.2.0.min.js')); ?>"></script>

<!-- Bootstrap 3.3.6 -->

<script type="text/javascript" src="<?php echo e(asset('bootstrap/js/bootstrap.min.js')); ?>"></script>
<!-- FastClick -->

<script type="text/javascript" src="<?php echo e(asset('plugins/fastclick/fastclick.js')); ?>"></script>
<!-- AdminLTE App -->

<script type="text/javascript" src="<?php echo e(asset('dist/js/app.min.js')); ?>"></script>
<!-- Sparkline -->

<script type="text/javascript" src="<?php echo e(asset('plugins/sparkline/jquery.sparkline.min.js')); ?>"></script>
<!-- jvectormap -->

<script type="text/javascript" src="<?php echo e(asset('plugins/jvectormap/jquery-jvectormap-1.2.2.min.js')); ?>"></script>

<!-- SlimScroll 1.3.0 -->

<script type="text/javascript" src="<?php echo e(asset('plugins/slimScroll/jquery.slimscroll.min.js')); ?>"></script>
<!-- ChartJS 1.0.1 -->

<script type="text/javascript" src="<?php echo e(asset('plugins/chartjs/Chart.min.js')); ?>"></script>
<!-- AdminLTE dashboard demo (This is only for demo purposes) -->

<script type="text/javascript" src="<?php echo e(asset('dist/js/pages/dashboard2.js')); ?>"></script>
<!-- AdminLTE for demo purposes -->

<script type="text/javascript" src="<?php echo e(asset('dist/js/demo.js')); ?>"></script>

<!-- GAUGE CHARTS GOOGLE -->
<script src="https://code.highcharts.com/highcharts.js"></script>
<script src="https://code.highcharts.com/highcharts-more.js"></script>
<script src="https://code.highcharts.com/modules/exporting.js"></script>
<script src="https://code.highcharts.com/modules/export-data.js"></script>

</html>

<?php echo $__env->make('layouts.header_section', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('layouts.row', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>