<!DOCTYPE html>
<html>
<head>


</head>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">
<?php echo $__env->yieldContent('header'); ?>
<body class="hold-transition skin-blue sidebar-mini">

<header class="main-header">
 <!-- Logo -->
 <a href="#" class="logo">
      
      <!-- mini logo for sidebar mini 50x50 pixels -->
      <span class="logo-mini"><b>A</b>L</span>
      <!-- logo for regular state and mobile devices -->
      <span class="logo-lg"><b>A</b>LEXA</span>
           <img src="https://ripleycl.imgix.net/https%3A%2F%2Ftrello-attachments.s3.amazonaws.com%2F57f241c05e557d866cbb89d2%2F5c8bbc6e79dd6f6ee3b1fbce%2Feaa29d53eafc4b743a544f4ee5fa26a4%2Famazon-echo-dot-3rd-foto3.jpg?w=750&h=555&ch=Width&auto=format&cs=strip&bg=FFFFFF&q=60&trimcolor=FFFFFF&trim=color&fit=fillmax&ixlib=js-1.1.0&s=23239e45bf1a4cbf1d36eab5edf63708" style="border-radius: 50%; width: 60px; heigth: 45px" alt="">

    </a>

    <!-- Header Navbar: style can be found in header.less -->
    <nav class="navbar navbar-static-top">
    </nav>

</header>



</body>