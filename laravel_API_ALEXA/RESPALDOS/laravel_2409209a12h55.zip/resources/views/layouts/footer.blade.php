<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    @yield('footer')
    <footer class="main-footer">
            <div class="pull-right hidden-xs">
                <b>Alexa</b> Indicadores
            </div>
            <img class="img-circle img-bordered-sm" src="http://www.sidesoft.com.ec/wp-content/uploads/2015/10/Logo2014v1.png" image" style="width: 10%">

        </footer>
</body>
</html>