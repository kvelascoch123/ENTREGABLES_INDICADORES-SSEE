<?php

use Illuminate\Http\Request;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware('auth:api')->get('/user', function (Request $request) {
    return $request->user();
});

Route::prefix('alexa')->group(function () {
    //***** USER 
    //login
    Route::get('user/{nombre}/{contrasena}','API\APIController@getUser'); 
    //usuario name
    Route::get('user/{nombre}','API\APIController@getUser_validate'); //http://www.sidesoft.com.ec/app_indicadores/api/alexa/user/kevi

    // ***** INDICADORES
    // area
    Route::get('areas','API\APIController@getArea'); //http://www.sidesoft.com.ec/app_indicadores/alexa/areas
    Route::get('area/{description}','API\APIController@getAreaDescription'); //http://www.sidesoft.com.ec/app_indicadores/alexa/area/NOMBRE
    Route::get('indicadores/{nombreFactor}','API\APIController@getIndicatorByFactor'); //http://www.sidesoft.com.ec/app_indicadores/alexa/area/NOMBRE

    //***** MONTHLY
    Route::get('monthly/{anio}/{nombre}','API\APIController@getMonthly'); //http://www.sidesoft.com.ec/app_indicadores/alexa/areas
    Route::get('monthly/{mes}/{anio}/{nombre?}','API\APIController@getMonthlyMonth'); //http://www.sidesoft.com.ec/app_indicadores/alexa/areas
    
    //**** COMPARATION
    Route::get('comparation/{nombre}','API\APIController@comparation'); //http://www.sidesoft.com.ec/app_indicadores/alexa/areas

    Route::get('test/{nombre?}','API\APIController@defaultP'); //http://www.sidesoft.com.ec/app_indicadores/alexa/areas


});
