<?php

namespace App\Repositories;

use Illuminate\Pagination\Paginator;
use Illuminate\Support\Facades\DB;

use Carbon\Carbon; 


class APIServiceRepository {

    public function __construct() {    
    }
    
    // Usuario
    public function getUser($nombre, $contrasena) {
        $user = DB::select('SELECT * FROM `al_user` WHERE alias_name ="' . strtolower($nombre) . '" and  user_password = "' . strtolower($contrasena) . '"');     
        return $user;
    }
    
    // Validacion completa login
     public function getUser_validate($nombre) {
        $user = DB::select('SELECT * FROM `al_user` WHERE alias_name ="' . strtolower($nombre) . '" ');     
        return $user;
    }
    // *** INDICADORES ****
    // getArea
     public function getArea() {
        $areas = DB::select('select name from al_area');     
        return $areas;
    }
    
    // getArea
     public function getAreaDescription($area) {
        $factor_area = DB::select('select al_f.name from al_factor as al_f inner join al_area as al_a on al_f.al_area_id = al_a.al_area_id where al_a.description = "'.$area.'"');     
        return $factor_area;
    }
    
    //
      public function getIndicatorByFactor($factor) {
        $indicator = DB::select('select al_i.name from al_indicators as al_i inner join al_factor as al_f on al_i.al_factor_id = al_f.al_factor_id where al_f.name ="'.$factor.'"');     
        return $indicator;
    }
    
    // *** MONTHLY**
    // Q.1
    public function getMonthly( $anio, $nombre){
        $monthCurrentYear = DB::select('SELECT SUM(current_year) as sumaActual, SUM(last_year) as sumaAnterior FROM `al_indicators_years` WHERE name = "'.$nombre.'" and year = "'.$anio.'"');     
        return  $monthCurrentYear;
    }
    //Q.2
     public function getMonthlyMonth( $mes, $anio, $nombre){
        $monthCurrentYearMonth = DB::select('select last_month, current_month, variation_between_months, criterial, description from al_indicators_years where month ="'.$mes.'" and year = '."$anio".' and name = "'.$nombre.'"');     
        return  $monthCurrentYearMonth;
    }
    
    // Interpretacion COmparacion
      public function comparation( $nombre){
        $resp_comparation = DB::select('select txt_affirmative from al_indicators where name = "'.$nombre.'"');   
        return $resp_comparation;
      }
    
    
}